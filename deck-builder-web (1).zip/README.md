
# Deck Builder (Mobile Web) — React + dnd-kit

Touch-first deck building UI for mobile web built with React, TypeScript, Vite, and dnd-kit.

Now with:
- History state with undo/redo. Drag operations are ephemeral until drop; only final drops are committed to history.
- Hard page scroll lock. The page never scrolls; an internal `.content` container scrolls instead. Zones themselves are scrollable.
- Drag cards between zones and reorder inside zones with placeholder gap.
- Edge auto-scroll near zone edges during drag.
- A11y announcements and keyboard drag.

## Quick start

```bash
pnpm i   # or: npm i  or: yarn
pnpm dev # or: npm run dev
```

## Key files

- `src/state/useHistoryState.ts` — baselined history with `setEphemeral`, `commit`, `undo`, `redo`.
- `src/util/scrollLock.tsx` — page scroll lock mounted at app root.
- `src/dnd/useEdgeAutoScroll.ts` — edge-scrolling helper.
- `src/App.tsx` — integrates history and scroll lock with dnd-kit.
