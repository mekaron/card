
import React from 'react';
import {
  DndContext, DragOverlay, KeyboardSensor, PointerSensor, useSensor, useSensors,
  closestCenter, type DragEndEvent, type DragOverEvent, type DragStartEvent
} from '@dnd-kit/core';
import {
  SortableContext, rectSortingStrategy, verticalListSortingStrategy, sortableKeyboardCoordinates,
} from '@dnd-kit/sortable';

import Zone from './components/Zone';
import Card from './components/Card';
import DragOverlayCard from './components/DragOverlayCard';
import A11yLiveRegion from './components/A11yLiveRegion';
import { useEdgeAutoScroll } from './dnd/useEdgeAutoScroll';
import type { ZoneId, Card as CardT, ZoneState, CardsById } from './types';
import { arrayMove } from './util/array';
import { announce, vibrate } from './util/a11y';
import { useHistoryState } from './state/useHistoryState';
import { PageScrollLock } from './util/scrollLock';

type Id = string;

const initialCards: CardsById = {
  'c-01': { id: 'c-01', label: 'Scout', type: 'unit' },
  'c-02': { id: 'c-02', label: 'Archer', type: 'unit' },
  'c-03': { id: 'c-03', label: 'Knight', type: 'unit' },
  'c-04': { id: 'c-04', label: 'Mage Bolt', type: 'spell' },
  'c-05': { id: 'c-05', label: 'Fireball', type: 'spell' },
  'c-06': { id: 'c-06', label: 'Healer', type: 'unit' },
  'c-07': { id: 'c-07', label: 'Rogue', type: 'unit' },
  'c-08': { id: 'c-08', label: 'Ice Nova', type: 'spell' },
};

const initialZones: ZoneState = {
  hand: ['c-01', 'c-03', 'c-04', 'c-05', 'c-06', 'c-07', 'c-08'],
  board: ['c-02'],
  discard: [],
};

function findContainer(containers: ZoneState, id: Id | null): ZoneId | null {
  if (!id) return null;
  const allZones = Object.keys(containers) as ZoneId[];
  if (allZones.includes(id as ZoneId)) return id as ZoneId;
  return allZones.find((z) => containers[z].includes(id)) ?? null;
}

function canDrop(card: CardT, toZone: ZoneId): boolean {
  if (toZone === 'board') return card.type === 'unit';
  return true;
}

export default function App() {
  const [cardsById] = React.useState<CardsById>(initialCards);
  const state = useHistoryState<ZoneState>(initialZones);
  const containers = state.present;

  const [activeId, setActiveId] = React.useState<Id | null>(null);
  const [hint, setHint] = React.useState<Record<ZoneId, 'accepts' | 'rejects' | null>>({ hand: null, board: null, discard: null });

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { delay: 180, tolerance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const isDragging = () => activeId != null;
  const { register } = useEdgeAutoScroll(isDragging, { edge: 32, maxSpeed: 600 });

  const activeCard = activeId ? cardsById[activeId] : null;
  const zoneRefs = React.useRef<Record<ZoneId, HTMLElement | null>>({ hand: null, board: null, discard: null });
  function registerZoneRef(zone: ZoneId, el: HTMLElement | null) {
    zoneRefs.current[zone] = el;
    if (el) register(el, zone);
  }

  function undo() { state.undo(); announce('Undid last move'); }
  function redo() { state.redo(); announce('Redid move'); }

  function onDragStart(e: DragStartEvent) {
    const { active } = e;
    setActiveId(active.id as string);
    vibrate(10);
    announce('Picked up ' + cardsById[active.id as string].label);
  }

  function onDragOver(e: DragOverEvent) {
    const { active, over } = e;
    if (!over) return;
    const activeId = active.id as string;
    const overId = over.id as string;

    const from = findContainer(containers, activeId);
    const to = findContainer(containers, overId);
    if (!from || !to) return;

    if (from === to) {
      const activeIndex = containers[from].indexOf(activeId);
      const overIndex = containers[from].indexOf(overId);
      if (activeIndex !== overIndex && overIndex >= 0) {
        state.setEphemeral((prev) => ({ ...prev, [from]: arrayMove(prev[from], activeIndex, overIndex) }));
      }
      return;
    }

    const card = cardsById[activeId];
    setHint((h) => ({ ...h, [to]: canDrop(card, to) ? 'accepts' : 'rejects' }));

    state.setEphemeral((prev) => {
      const fromItems = prev[from].filter((id) => id !== activeId);
      const toItems = prev[to].slice();
      const overIndex = toItems.indexOf(overId);
      const insertAt = overIndex >= 0 ? overIndex : toItems.length;
      toItems.splice(insertAt, 0, activeId);
      return { ...prev, [from]: fromItems, [to]: toItems };
    });
  }

  function onDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    const id = active.id as string;
    setHint({ hand: null, board: null, discard: null });

    if (!over) {
      setActiveId(null);
      state.replace(state.baseline); // revert all ephemeral
      announce('Cancelled');
      return;
    }

    const from = findContainer(containers, id);
    const to = findContainer(containers, over.id as string);
    if (!from || !to) { setActiveId(null); return; }

    const card = cardsById[id];
    if (!canDrop(card, to)) {
      vibrate([5, 20, 30]);
      announce(`Invalid drop: ${card.type} cannot be placed on ${to}`);
      state.replace(state.baseline); // bounce back
      setActiveId(null);
      return;
    }

    state.commit(undefined, { type: 'drop', card: id, from, to });
    setActiveId(null);
    vibrate(8);
    announce(`Dropped ${card.label} on ${to}`);
  }

  return (
    <div className="app">
      <PageScrollLock />
      <A11yLiveRegion />

      <header className="header">
        <div className="title">Deck Builder</div>
        <div className="actions">
          <button onClick={undo} className="danger" aria-label="Undo last move" disabled={!state.canUndo}>Undo</button>
          <button onClick={redo} aria-label="Redo" disabled={!state.canRedo}>Redo</button>
          <button className="primary" onClick={() => { state.replace(initialZones); announce('Reset'); }}>Reset</button>
        </div>
      </header>

      <div className="content">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={onDragStart}
          onDragOver={onDragOver}
          onDragEnd={onDragEnd}
          onDragCancel={() => { setActiveId(null); state.replace(state.baseline); announce('Cancelled'); }}
        >
          <div className="zones">
            <Zone id="hand" title="Hand" accepts={['unit', 'spell']} onRef={(el) => registerZoneRef('hand', el)} hint={hint.hand}>
              <SortableContext items={containers.hand} strategy={verticalListSortingStrategy}>
                <div className="list">
                  {containers.hand.map((id) => <Card key={id} card={cardsById[id]} />)}
                </div>
              </SortableContext>
            </Zone>

            <Zone id="board" title="Board" accepts={['unit']} onRef={(el) => registerZoneRef('board', el)} hint={hint.board}>
              <SortableContext items={containers.board} strategy={rectSortingStrategy}>
                <div className="grid">
                  {containers.board.map((id) => <Card key={id} card={cardsById[id]} />)}
                </div>
              </SortableContext>
            </Zone>

            <Zone id="discard" title="Discard" accepts={['unit', 'spell']} onRef={(el) => registerZoneRef('discard', el)} hint={hint.discard}>
              <SortableContext items={containers.discard} strategy={verticalListSortingStrategy}>
                <div className="list">
                  {containers.discard.map((id) => <Card key={id} card={cardsById[id]} />)}
                </div>
              </SortableContext>
            </Zone>
          </div>

          <DragOverlay dropAnimation={{ duration: 130 }}>
            {activeCard ? <DragOverlayCard card={activeCard} /> : null}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  );
}
