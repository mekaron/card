
import * as React from 'react';

type Updater<T> = T | ((prev: T) => T);

export interface HistoryState<T> {
  present: T;
  commit: (next?: Updater<T>, meta?: any) => void;
  setEphemeral: (next: Updater<T>) => void;
  replace: (next: Updater<T>) => void;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  clear: () => void;
  baseline: T;
  log: { at: number; meta?: any }[];
}

export function useHistoryState<T>(initial: T, opts?: { capacity?: number }): HistoryState<T> {
  const capacity = Math.max(1, opts?.capacity ?? 100);
  const [present, setPresent] = React.useState<T>(initial);
  const [past, setPast] = React.useState<T[]>([]);
  const [future, setFuture] = React.useState<T[]>([]);
  const baselineRef = React.useRef<T>(initial);
  const [log, setLog] = React.useState<{ at: number; meta?: any }[]>([]);

  const setEphemeral = React.useCallback((next: Updater<T>) => {
    setPresent(p => typeof next === 'function' ? (next as any)(p) : next);
  }, []);

  const replace = React.useCallback((next: Updater<T>) => {
    setPresent(p => typeof next === 'function' ? (next as any)(p) : next);
    baselineRef.current = typeof next === 'function' ? (next as any)(baselineRef.current) : next;
  }, []);

  const commit = React.useCallback((next?: Updater<T>, meta?: any) => {
    setPresent(prev => {
      const desired = next ? (typeof next === 'function' ? (next as any)(prev) : next) : prev;
      setPast(p => [baselineRef.current, ...p].slice(0, capacity));
      baselineRef.current = desired;
      setFuture([]);
      setLog(l => [{ at: Date.now(), meta }, ...l].slice(0, capacity));
      return desired;
    });
  }, [capacity]);

  const undo = React.useCallback(() => {
    setPast(pastArr => {
      if (pastArr.length === 0) return pastArr;
      const [previous, ...rest] = pastArr;
      setFuture(f => [baselineRef.current, ...f].slice(0, capacity));
      baselineRef.current = previous;
      setPresent(previous);
      return rest;
    });
  }, [capacity]);

  const redo = React.useCallback(() => {
    setFuture(fArr => {
      if (fArr.length === 0) return fArr;
      const [next, ...rest] = fArr;
      setPast(p => [baselineRef.current, ...p].slice(0, capacity));
      baselineRef.current = next;
      setPresent(next);
      return rest;
    });
  }, [capacity]);

  const clear = React.useCallback(() => {
    setPast([]);
    setFuture([]);
    setLog([]);
    baselineRef.current = present;
  }, [present]);

  return {
    present,
    baseline: baselineRef.current,
    commit,
    setEphemeral,
    replace,
    undo,
    redo,
    canUndo: past.length > 0,
    canRedo: future.length > 0,
    clear,
    log,
  };
}
