
import React from 'react';
import type { Card as CardT } from '@/types';

export default function DragOverlayCard({ card }: { card: CardT }) {
  if (!card) return null;
  return (
    <div className={`card ${card.type} overlay`} aria-hidden="true">
      <span className="typeBadge">{card.type}</span>
      <div className="cardLabel">{card.label}</div>
    </div>
  );
}
