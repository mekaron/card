
export function announce(text: string) {
  const el = document.getElementById('live-region');
  if (!el) return;
  el.textContent = '';
  void (el as any).offsetHeight;
  el.textContent = text;
}

export function vibrate(ms: number | number[] = 15) {
  if ('vibrate' in navigator) {
    try { (navigator as any).vibrate(ms as any); } catch {}
  }
}
